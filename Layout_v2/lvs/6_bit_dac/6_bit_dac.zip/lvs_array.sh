netgen -batch lvs "6_bit_dac_with_array.ext.spice x6_bit_dac_with_array" "6_bit_dac.sch.spice 6_bit_dac" \
		  "$PDK_ROOT/$PDK/libs.tech/netgen/${PDK}_setup.tcl" \
		  comp_array.out
